"""Transparent rules corresponding to Lab 2, used as the offline baseline."""
from __future__ import annotations
from tools import assess_change_candidates, get_incident_signals, list_code_change_signals


def choose_attribution(thread_id: str) -> dict:
    signals = get_incident_signals(thread_id)["signals"]
    changes = list_code_change_signals(thread_id)["code_changes"]
    info = assess_change_candidates(thread_id, 30)
    candidates = info["candidates"]
    evidence_ids = [s["signal_id"] for s in signals if s.get("source") != "slack"]
    missing = []

    if not signals:
        choice, level, reason = None, "low", "The requested incident has no available signals."
        missing = ["incident signals"]
    elif not changes:
        choice, level, reason = None, "low", "No code-change signal was provided, so attribution is not possible."
        missing = ["code-change signal"]
    else:
        for c in candidates:
            missing.extend(c["missing_information"])
        missing = list(dict.fromkeys(missing))
        # A known service mismatch blocks attribution even if the change is recent.
        eligible = [c for c in candidates if c["service_match"] is not False]
        if missing:
            choice, level, reason = None, "low", "Important service or timing data is missing; the agent does not guess."
        elif not eligible:
            choice, level, reason = None, "low", "Available code changes affect a different service from the incident."
        else:
            top = max(c["confirmed_clues"] for c in eligible)
            best = [c for c in eligible if c["confirmed_clues"] == top]
            if len(best) > 1:
                choice, level, reason = None, "low", "Multiple code changes have equally strong evidence; a human must distinguish them."
            elif top == 0:
                choice, level, reason = None, "low", "Neither service nor timing attribution clue is confirmed."
            else:
                winner = best[0]
                choice = winner["signal_id"]
                level = "high" if top == 2 else "medium"
                gap = winner["minutes_before_failure"]
                if top == 2:
                    reason = (f"{choice} affected the {info['incident_service']} service and occurred "
                              f"{gap:g} minutes before the first failure, within the 30-minute window.")
                elif winner["service_match"]:
                    reason = f"{choice} affected the incident service, but its deployment was outside the 30-minute window."
                else:
                    reason = f"{choice} occurred in the 30-minute window, but its service could not be verified."
    return {
        "thread_id": thread_id,
        "attributed_change_signal_id": choice,
        "confidence": level,
        "evidence_signal_ids": evidence_ids,
        "reason": reason,
        "missing_information": missing,
    }
