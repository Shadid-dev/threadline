# INSE 691 — Lab 3: Tool-Using Change Attributor

**Student:** Ahmed Hantoor (40326983)  
**Purpose:** Extend the Lab 2 ThreadLine Change Attributor with genuinely useful read-only tools.

## Submission contents

- `Lab3_Verified_Live_Report.pdf` — main four-page report, including the 214-word reflection, test cases, and live-evidence appendix.
- `agent.py` — deterministic offline reference mode and Gemini model-directed custom function calling.
- `builtin_audit.py` — a **separate** native Gemini built-in `code_execution` audit.
- `tools.py`, `tool_schemas.json`, `attribution.py` — four custom tools, strictly validated schemas, 30-minute attribution logic, and semantic output checks.
- `fixtures/signals.json` — synthetic incident data.
- `test_prompts.py` and `tests/test_tools.py` — seven scenarios and twelve unit tests.
- `traces/trace_T01.txt` through `trace_T07.txt` — genuine offline tool-call traces.
- `traces/live_verification/` — the original live Gemini traces and short faithful summaries that the PDF appendix references.

## Test the package without an API key

Open PowerShell in the extracted ZIP folder:

```powershell
py -m pip install -r requirements.txt
py test_prompts.py
py -m unittest discover -s tests -v
py agent.py --thread THR-L301 --trace traces/my_trace.json
```

**Checked results for this package:** 7/7 scenario prompts; 12/12 unit tests. Offline mode follows a fixed sequence and does not claim autonomous LLM tool selection.

## Live Gemini testing (requires your own key)

The included historical provider traces show two Gemini 2.5 Flash custom-function investigations and one successful, separately registered native code-execution audit. **No API key is included.**

Set `GEMINI_API_KEY` privately in your own environment, then run individual commands such as:

```powershell
py agent.py --live --model gemini-2.5-flash --thread THR-L301 --trace traces/new_live_L301.json
py agent.py --live --model gemini-2.5-flash --thread THR-L302 --trace traces/new_live_L302.json
py builtin_audit.py --model gemini-2.5-flash --thread THR-L301 --trace traces/new_builtin.json
```

The original live `THR-L302` trace is intentionally preserved: Gemini said **low** confidence, whereas the deterministic baseline said **medium**. The old structural validator accepted that semantically incorrect label. This checked submission adds local policy-level checks and two regression tests to reject wrong confidence or selected change. **No live Gemini retest of the revised validator is claimed.** The `validated_baseline` event is not the model's answer.

The native code-execution tool runs in a separate request because the tested API/model combination did not support using it alongside custom function calling in a single request. All fixtures are synthetic, all tools are read-only, and any recommendation requires human review; the program cannot execute rollbacks or production changes.
