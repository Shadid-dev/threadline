"""Strict, read-only ThreadLine attribution tools. All fixture data are synthetic."""
from __future__ import annotations
import copy
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

BASE = Path(__file__).resolve().parent
DATA_FILE = BASE / "fixtures" / "signals.json"
SCHEMA_FILE = BASE / "tool_schemas.json"


def _all_signals() -> list[dict]:
    # A configurable local JSON path avoids external services and writes.
    target = Path(os.getenv("THREADLINE_FIXTURE", str(DATA_FILE)))
    with target.open(encoding="utf-8") as stream:
        records = json.load(stream)
    if not isinstance(records, list):
        raise ValueError("Signal fixture must be an array")
    return records


def _parse_timestamp(raw: Any) -> datetime | None:
    if not isinstance(raw, str):
        return None
    try:
        return datetime.strptime(raw, "%Y-%m-%dT%H:%M:%S")
    except ValueError:
        return None


def _thread_signals(thread_id: str) -> list[dict]:
    return [copy.deepcopy(s) for s in _all_signals() if s.get("thread_id") == thread_id]


def _is_change(s: dict) -> bool:
    # Only a known code-change source can establish a change. Log text alone cannot.
    return s.get("source") in {"github", "deployment"}


def _is_failure(s: dict) -> bool:
    # Sentry represents error records. Monitors qualify when their text marks a failure.
    if s.get("source") == "sentry":
        return True
    if s.get("source") == "monitor":
        content = str(s.get("content") or "").lower()
        return any(word in content for word in ("error", "fail", "crash", "outage"))
    return False


def get_incident_signals(thread_id: str) -> dict:
    """Look up signals for a single known incident, without reading unrelated incidents."""
    signals = _thread_signals(thread_id)
    return {"thread_id": thread_id, "signals": signals, "count": len(signals)}


def list_code_change_signals(thread_id: str) -> dict:
    """Return code-change signals only; never infer a missing deployment."""
    changes = [s for s in _thread_signals(thread_id) if _is_change(s)]
    return {"thread_id": thread_id, "code_changes": changes, "count": len(changes)}


def assess_change_candidates(thread_id: str, window_minutes: int) -> dict:
    """Calculate candidate evidence with strict, inclusive 0..30 minute time checks."""
    if type(window_minutes) is not int or window_minutes != 30:
        raise ValueError("Lab 2 contract requires a window of exactly 30 minutes")
    records = _thread_signals(thread_id)
    failures = [s for s in records if _is_failure(s)]
    complete_failures = [s for s in failures if _parse_timestamp(s.get("timestamp"))]
    first = min(complete_failures, key=lambda s: _parse_timestamp(s["timestamp"])) if complete_failures else None
    first_time = _parse_timestamp(first.get("timestamp")) if first else None
    incident_service = first.get("service") if first else None
    # If failure exists but has no date, the service can still be known.
    if first is None and failures:
        incident_service = failures[0].get("service")
    candidates = []
    for change in records:
        if not _is_change(change):
            continue
        service = change.get("service")
        change_dt = _parse_timestamp(change.get("timestamp"))
        service_match = (service == incident_service if service is not None and incident_service is not None else None)
        gap = (first_time - change_dt).total_seconds() / 60 if first_time and change_dt else None
        timing_match = (0 <= gap <= window_minutes) if gap is not None else None
        gaps = []
        if service is None: gaps.append(f"service of {change['signal_id']}")
        if incident_service is None: gaps.append("service of first failure")
        if change_dt is None: gaps.append(f"timestamp of {change['signal_id']}")
        if first_time is None:
            if failures and not complete_failures:
                gaps.extend(f"timestamp of {s['signal_id']}" for s in failures if _parse_timestamp(s.get("timestamp")) is None)
            else:
                gaps.append("first failure signal with timestamp")
        candidates.append({
            "signal_id": change["signal_id"],
            "service_match": service_match,
            "timing_match": timing_match,
            "minutes_before_failure": gap,
            "confirmed_clues": int(service_match is True) + int(timing_match is True),
            "missing_information": list(dict.fromkeys(gaps)),
        })
    return {
        "thread_id": thread_id, "first_failure_signal_id": first["signal_id"] if first else None,
        "first_failure_timestamp": first["timestamp"] if first else None,
        "incident_service": incident_service, "window_minutes": window_minutes,
        "candidates": candidates, "signal_count": len(records),
        "failure_signal_ids": [s["signal_id"] for s in failures],
    }


def validate_attribution_output(thread_id: str, decision: dict) -> dict:
    """Enforce Lab 2 output shape and evidence references, not just good prose."""
    schema = next(t["parameters"]["properties"]["decision"] for t in _schemas() if t["name"] == "validate_attribution_output")
    full = next(t["parameters"]["definitions"]["attribution"] for t in _schemas() if t["name"] == "validate_attribution_output")
    errors = [e.message for e in Draft202012Validator(full).iter_errors(decision)]
    if isinstance(decision, dict):
        if decision.get("thread_id") != thread_id:
            errors.append("Output thread_id does not match requested incident")
        actual = {s.get("signal_id") for s in _thread_signals(thread_id)}
        for sid in decision.get("evidence_signal_ids", []):
            if sid not in actual: errors.append(f"Unknown evidence signal: {sid}")
        selected = decision.get("attributed_change_signal_id")
        if selected is not None:
            if selected not in {s["signal_id"] for s in _thread_signals(thread_id) if _is_change(s)}:
                errors.append("Attributed signal is not a known code-change signal")
    # Shape validation alone is not enough: compare attribution policy too.
    # Delayed import avoids a circular import with attribution.py.
    if not errors and isinstance(decision, dict):
        from attribution import choose_attribution
        expected = choose_attribution(thread_id)
        for field in ("attributed_change_signal_id", "confidence"):
            if decision.get(field) != expected[field]:
                errors.append(f"Policy mismatch: {field}; expected {expected[field]!r}")
    return {"valid": not errors, "errors": errors}


def _schemas() -> list[dict]:
    with SCHEMA_FILE.open(encoding="utf-8") as src:
        return json.load(src)["tools"]


AVAILABLE = {
    "get_incident_signals": get_incident_signals,
    "list_code_change_signals": list_code_change_signals,
    "assess_change_candidates": assess_change_candidates,
    "validate_attribution_output": validate_attribution_output,
}


def execute_tool(name: str, arguments: dict) -> dict:
    """Server-side schema validation before dispatch; no tools can mutate state."""
    if name not in AVAILABLE:
        return {"ok": False, "error": "Unknown or prohibited tool"}
    spec = next(x for x in _schemas() if x["name"] == name)
    failures = sorted(Draft202012Validator(spec["parameters"]).iter_errors(arguments), key=lambda e: str(e.path))
    if failures:
        return {"ok": False, "error": "Invalid arguments", "details": [e.message for e in failures]}
    try:
        return {"ok": True, "result": AVAILABLE[name](**arguments)}
    except Exception as exc:
        return {"ok": False, "error": f"Tool failed: {type(exc).__name__}: {exc}"}
