# ThreadLine Lab 3 Action Drafter

Kameshwar Arora | INSE 691 | Fall 2026

This extends the Action Drafter contract from Lab 2. It proposes investigation or conditional mitigation and drafts an internal update. No tool sends messages, changes an incident or operates a service.

## Verification status

Eight deterministic fixture scenarios ran locally and seven unittest methods passed. The supplied live batch retained one completed T1 run and recorded HTTP 429 failures for T2 through T8. T1 includes actual custom function calls and provider-built-in code execution, independently checked locally. Behavioral review found unsupported ongoing-work wording, missing inline references and a Lab 2 status mismatch in T1. An archived T2 run contains a complete model draft inside Markdown fences; the old parser failed before native auditing. The parser fix validates that saved answer locally. No remote T2 success is claimed.

See the report and Captured traces.json for the two prompt traces, actual final model answers, audit evidence and limitations. Tests do not need to succeed to be useful evidence; failures are reported explicitly.

## Run locally

Use Python 3.10 or later. In this folder run:

```sh
python -m pip install -r requirements.txt
python baseline.py
python "test prototype.py"
```

The baseline writes `traces/offline T1.json` through `traces/offline T8.json`. Each includes its prompt, full snapshot, tool arguments, actual local results and final deterministic draft. `baseline.py` uses explicit fixture branches; it is not a replacement for the live agent.

## Run the actual agent

Configure `GEMINI_API_KEY` privately as an environment variable. Do not put a key in a source file, chat message, ZIP or committed file. Choose a Gemini model available to your account that supports function calling and native code execution. For example, after checking model availability:

```sh
python agent.py --model YOUR_MODEL_ID --case T1
python agent.py --model YOUR_MODEL_ID --all --resume
```

An optional `--audit-model YOUR_AUDIT_MODEL_ID` selects a separate code execution model. Each case sends the synthetic snapshot to Gemini, handles custom function calls with local schema validation, validates the final JSON, and then schedules the native built-in citation audit in a separate request. It may make billable requests. Traces go to `traces/live T1.json`, etc. Failed runs also save their status and error. The current T1 trace is the supplied completed Gemini 3.8 Flash run.

Successful live evidence must include custom calls, their results, a final draft, executableCode and codeExecutionResult with OUTCOME_OK. The program compares the built-in calculation against a local oracle. A missing or failed execution causes failure rather than a simulated success. The recorded traces show T1 and the earlier T2 attempt. Further live runs can evaluate incomplete cases when provider limits permit. Use --resume to retain completed traces. Requests are spaced by 20 seconds and transient errors have bounded retries. This cannot override daily quota limits.

## Files

- `agent.py`: live REST function loop and native built-in code execution audit.
- `tools.py`: snapshot inspection, rollback prerequisite check, schema and citation validation.
- `instructions.txt`: Lab 3 developer contract.
- `tool schemas.json`: enforced strict custom input schemas.
- `output schema.json`: original Lab 2 output schema.
- `fixtures/cases.json`: eight synthetic inputs and exact test prompts.
- `baseline.py`: deterministic local demonstration.
- `test prototype.py`: local verification including stubbed provider response checks.
- `traces/`: local evidence and failed live startup record.
- `Lab 3 Report.docx`: background, design, tests, two trace summaries and reflection.

## Limits

The prototype checks structure and citation membership, not whether every natural-language claim is supported. The rollback gate checks declared prerequisites; it cannot confirm real service state. Prompt instructions are not proof of injection resistance. There is no deployed approval queue or production integration. The application schedules the built-in audit; the model does not autonomously choose between built-in and custom tools in a single request.
