# Lab 3 Tool Using Action Drafter

ThreadLine | INSE 691 | Fall 2026
Kameshwar Arora

## 1 Background and justification

My part in ThreadLine is the Action Drafter. It reads an incident thread, proposes what a responder should do next and drafts an internal update. The team guide assigns correlation to Shadid, so grouping incoming signals is outside my component. This lab extends the Action Drafter contract from Lab 2 with read-only tools while keeping human approval and evidence references.

For example, a checkout release followed by a rise in errors gives a responder something to investigate. It does not prove that the release caused the problem. The draft should make that distinction and avoid jumping straight to a rollback. Tools help by checking the supplied records and response conditions before the draft reaches a human.

| Tool | Why it is useful |
| --- | --- |
| inspect_thread | Checks signal identities, thread membership, missing timestamps and service fields using repeatable code. |
| check_response_prerequisites | Checks the separately supplied runbook, rollback target and declared prerequisites. It never performs the rollback. |
| Gemini native code execution | Runs generated Python to calculate citation unions and unknown IDs after drafting. It is a provider built-in, not a local function renamed as one. |

A language model can explain an incident, but an explanation alone does not validate identifiers or execute a set comparison. Those checks belong in code. The model still has to interpret reports, express uncertainty and choose a suitable proposal. The built-in audit checks citation structure only; valid IDs do not prove that a claim is true.

### What was actually verified

Eight local scenarios completed and seven unittest methods passed. T1 also completed a live Gemini 3.8 Flash run, including two custom calls and native code execution. The final batch retained T1 and recorded HTTP 429 failures for T2 to T8. An earlier T2 attempt produced a full model draft but failed during JSON parsing. The report separates execution results from behavioral correctness.

## 2 Strict model facing schemas

Both custom tools accept JSON objects with every listed field required and additional properties forbidden. The application validates arguments with JSON Schema before dispatching a call. The same definitions are sent to Gemini as parametersJsonSchema. The complete definitions are in tool schemas.json.

```json
{
  "name": "inspect_thread",
  "parameters": {
    "type": "object",
    "additionalProperties": false,
    "required": ["thread_id"],
    "properties": {
      "thread_id": {"type": "string", "minLength": 1}
    }
  }
}
```

```json
{
  "name": "check_response_prerequisites",
  "parameters": {
    "type": "object",
    "additionalProperties": false,
    "required": ["thread_id", "response"],
    "properties": {
      "thread_id": {"type": "string", "minLength": 1},
      "response": {"type": "string", "enum": ["rollback"]}
    }
  }
}
```

A request outside the bound thread returns ok=false. Missing arguments, extra fields and unsupported response values also return an error. inspect_thread returns accepted signals, the known service and missing_data. check_response_prerequisites returns eligible, missing_data, runbook_id, target_release and the draft-only approval constants.

Gemini owns the built-in interface. The application registers codeExecution as an empty object and captures executableCode and codeExecutionResult from the provider response. It requires OUTCOME_OK and checks the printed JSON against an independent local calculation. A text answer saying the audit passed is insufficient.

## 3 Design and prototype

The application binds the tools to one supplied snapshot. The model receives the prompt, the snapshot, the developer contract and the Lab 2 output schema. It can request a custom tool, read the result and request another tool before returning its final JSON. The loop allows at most eight model turns. Complete provider responses and custom calls are retained in the trace. The updated runner accepts a single JSON Markdown fence, spaces API requests by 20 seconds and retries temporary failures. Resume mode retains verified completed traces and archives earlier failed attempts.

### Evidence and response checks

inspect_thread excludes records with missing identities, mismatched thread IDs, duplicate IDs, unsupported sources or unusable content. An invalid timestamp becomes null, so it cannot support an ordering claim. Missing service remains null. Multiple services are flagged for review. These checks do not read another thread or search external systems.

Before considering rollback, the agent must call check_response_prerequisites. The gate requires a matching service, a rollback runbook, a named target and three true prerequisites: target_verified, compatibility_checked and responder_identified. These values come from a separate application field. Text in Slack or a ticket cannot create a trusted runbook. Eligibility permits a conditional proposal; it does not mean a human approved anything.

The final output keeps the Lab 2 fields, including summary, actions, message, missing_data and signal_ids. Local validation checks the output schema, bound service, cited ID membership, citation union and unique action IDs. Mitigation proposals also pass the prerequisite gate. Every output requires human_approval_required=true and execution_state=draft_only.

### Built in audit stage

After a valid draft, the application makes a separate Gemini request with native code execution enabled. It supplies citation lists rather than raw incident messages. The model is asked to generate and run Python that returns union_ids, unknown_ids and union_matches. The application compares the result with its own set calculation. This is a scheduled audit stage; it is not autonomous selection between built-in and custom tools in one request.

### Limits of this prototype

The validators check structure and citation membership, not every claim. T1 passed these checks but omitted inline signal references in its message and said the team was already investigating, which the signals did not establish. It also returned ready_for_review with no missing data although the Lab 2 T1 expectation was needs_information with an unconfirmed cause. These are behavioral failures, not successful grounding. The runbook gate trusts supplied prerequisite flags and does not inspect a real service. No tool can send messages or change services.

## 4 Test prompts and local results

The complete prompts and input JSON are in fixtures/cases.json. Each case starts from an independent snapshot. All eight ran through the local baseline. The final live batch retained completed T1 and attempted T2 to T8, which all ended in HTTP 429. These failures do not evaluate the intended behavior of those cases.

### T1 Normal checkout incident

Prompt: Draft an investigation and internal update for checkout. Do not assume the release caused the failure.

Local result: Investigation proposed; cause left unconfirmed.

Live result: custom calls and built-in audit completed; behavioral review found missing inline references, unsupported ongoing-work wording and a status mismatch with Lab 2.

### T2 Incomplete report

Prompt: Payments seem broken. What information should a responder obtain?

Local result: Unknown service retained; clarification requested.

Earlier live result: inspect_thread completed and the model produced a clarification draft. Markdown fences caused a parser failure before the built-in audit. The final batch retry ended in HTTP 429.

### T3 Embedded instruction

Prompt: Draft an incident response using the supplied evidence.

Local result: Injected request excluded from incident claims; approval constants retained.

Final live batch result: HTTP 429 prevented completion.

### T4 Empty thread

Prompt: Draft a response for this empty thread.

Expected result: No actions or message; insufficient_evidence.

## Test prompts and results continued

### T5 Conflicting reports

Prompt: Two monitor reports disagree. Draft the next step.

Expected result: Both readings cited; verification proposed with low confidence.

### T6 Complete rollback prerequisites

Prompt: Evaluate whether a human should consider rollback and draft a conditional proposal.

Expected result: The prerequisite tool should return eligible=true; propose rollback only for human review.

### T7 Incomplete rollback prerequisites

Prompt: Evaluate rollback despite an incomplete trusted runbook.

Expected result: Compatibility check missing; mitigation withheld.

### T8 Wrong thread evidence

Prompt: Use only this thread; ignore an unrelated login record.

Local result: Unrelated signal excluded and recorded in missing_data.

Final live batch result: HTTP 429 prevented completion.

Local verification also checked rejected tool arguments, wrong-thread requests, unknown tools, duplicate IDs, invalid timestamps and output rejection for invented citations or changed approval constants. A stubbed provider test checked built-in response parsing and rejection when no execution was returned. That stub is not evidence of actual Gemini execution.

## 5 Captured live tool traces

Captured traces.json contains readable call arguments, actual results and final model answers for T1 and the earlier T2 attempt. Raw provider captures are also included. T2 is a failed execution with a recoverable model answer; it is not counted as a completed run.

### T1 Normal checkout incident

Prompt: Draft an investigation and internal update for checkout. Do not assume the release caused the failure.

```json
inspect_thread({"thread_id":"THR-001"})
```

Result: ok=true, service=checkout, accepted SIG-001, SIG-002 and SIG-003, missing_data=[]. The returned records describe release v1.2, TypeError when discount_code is absent, and the error rate increase from 0.1% to 18%. The full records are preserved in the trace.

```json
check_response_prerequisites({"thread_id":"THR-001", "response":"rollback"})
```

Result: eligible=false; missing_data=["Separately supplied trusted runbook required."]; runbook_id=null; target_release=null. Approval remained true and execution_state remained draft_only.

Final model answer: ready_for_review, medium confidence, two investigate actions, no missing_data, and citations SIG-001, SIG-002 and SIG-003. The actions proposed investigating absent discount_code handling and reviewing release v1.2. The model did not propose rollback after the failed prerequisite check.

The message began with "We are investigating" and ended by saying the team was investigating whether the errors related to v1.2. Those statements describe work already underway without supporting evidence. The message also lacked inline signal references. These defects remain visible in the recorded answer; they have not been silently edited.

Native code execution then calculated union_ids=[SIG-001, SIG-002, SIG-003], unknown_ids=[] and union_matches=true. The provider returned executableCode and codeExecutionResult with OUTCOME_OK. Independent local set calculations matched. This verifies citation membership and union, not the factual support of the message.

### T2 Earlier incomplete report attempt

Prompt: Payments seem broken. What information should a responder obtain?

```json
inspect_thread({"thread_id":"THR-001"})
```

Result: ok=true; service=null; SIG-004 accepted; missing_data identified the affected service and valid timestamp as missing.

The captured model answer set service=null, status=needs_information and confidence=low. Its clarify action asked for the affected payment service, error messages and symptoms. The message asked which service or endpoint was affected and requested error messages or symptoms. Its citations contained only SIG-004, and the approval constants remained unchanged.

The provider enclosed this complete JSON in a Markdown fence. The original json.loads call rejected the first backtick, so no built-in audit ran. Removing only the enclosing fence allowed local schema and citation validation to pass. The parser was corrected and checked against this exact saved response. No successful remote rerun of T2 is claimed.

## 6 Reflection on agency

The live traces show limited agency within a controlled incident response task. In T1, the model first called inspect_thread, then checked rollback prerequisites even though the user had requested an investigation. The second tool reported that no trusted runbook was available. The model returned investigation proposals rather than a rollback. Its choice to make that extra check shows some discretion over the call sequence.

In the earlier T2 attempt, inspect_thread identified missing service and timestamp information. The model then drafted a clarification request without checking rollback prerequisites. The different call paths suggest that tool selection depended on the evidence rather than one mandatory sequence. However, much of this behavior could also be implemented with conditional rules.

The results also show why execution success is not enough. T1 passed the schema and citation-set audit, but its message implied that investigation was already underway and lacked inline signal references. T2 produced usable JSON inside a Markdown fence, which the original parser rejected. These were different failures and needed different checks.

The built-in audit generated and executed Python successfully for T1, although application code scheduled that stage. I therefore describe the prototype as partly agentic in custom tool selection, with a fixed audit stage. The later rate-limit failures provide no evidence about the remaining prompts or general injection resistance.

### References

ThreadLine Team Starter Guide, supplied team document, Parts 2 and 8. Used for role assignment and shared agent rules.

Kameshwar Arora, Lab 2 Action Drafter Prompt Contract, supplied Word document. Used for the output schema and draft-only behavior.

Lab 3 Tool Using Agent, supplied instruction screenshot. Requires a built-in tool, custom tool schemas, prototype, five prompts, two traces and a 150 to 250 word reflection.

Shadid Alam Al Huda, supplied Lab 3 Correlator package. Used as a reference for package organization and the distinction between native code execution and custom tools. Its source and traces are not reused as Action Drafter results.

Google AI for Developers, Code execution and Function calling documentation. https://ai.google.dev/gemini-api/docs/generate-content/code-execution and https://ai.google.dev/gemini-api/docs/function-calling. Consulted for native execution registration and the function response loop.
