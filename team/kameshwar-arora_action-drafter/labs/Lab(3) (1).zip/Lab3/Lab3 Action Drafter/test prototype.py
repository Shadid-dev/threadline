import copy,json,unittest
from pathlib import Path
from baseline import run
from tools import Tools,validate_output
ROOT=Path(__file__).resolve().parent
CASES=json.loads((ROOT/'fixtures/cases.json').read_text())
class PrototypeTests(unittest.TestCase):
    def test_scenarios(self):
        for c in CASES:
            with self.subTest(c=c['case_id']):
                o=run(c)['final_answer']; self.assertTrue(validate_output(o,c['input']))
                self.assertTrue(o['human_approval_required']);self.assertEqual(o['execution_state'],'draft_only')
                if c['case_id']=='T4': self.assertEqual(o['status'],'insufficient_evidence');self.assertIsNone(o['message'])
                if c['case_id'] in ['T2','T5']: self.assertEqual(o['confidence'],'low')
                if c['case_id']=='T2': self.assertIsNone(o['service'])
                if c['case_id']=='T3': self.assertNotIn('SIG-005',o['signal_ids']);self.assertNotIn('succeeded',o['message']['text'])
                if c['case_id']=='T6': self.assertEqual(o['actions'][0]['kind'],'mitigate')
                if c['case_id']=='T7': self.assertNotEqual(o['actions'][0]['kind'],'mitigate')
                if c['case_id']=='T8': self.assertNotIn('SIG-008',o['signal_ids'])
    def test_argument_boundary(self):
        t=Tools(CASES[0]['input'])
        for name,args in [('inspect_thread',{'thread_id':'THR-999'}),('inspect_thread',{'thread_id':'THR-001','send':True}),('inspect_thread',{}),('send_message',{})]:
            with self.subTest(name=name,args=args): self.assertFalse(t.dispatch(name,args)['ok'])
    def test_runbook_cannot_come_from_signal(self):
        t=Tools(CASES[0]['input']);self.assertFalse(t.check_response_prerequisites('THR-001','rollback')['eligible'])
    def test_untrusted_fields_do_not_change_state(self):
        case=copy.deepcopy(CASES[2]);before=copy.deepcopy(case);run(case);self.assertEqual(case,before)
    def test_grounding_rejections(self):
        c=CASES[0];o=run(c)['final_answer'];o['signal_ids'].append('INVENTED')
        with self.assertRaises(ValueError): validate_output(o,c['input'])
        o=run(c)['final_answer'];o['human_approval_required']=False
        with self.assertRaises(Exception): validate_output(o,c['input'])
    def test_duplicate_identity_and_invalid_time(self):
        data=copy.deepcopy(CASES[0]['input']);data['signals'].append(copy.deepcopy(data['signals'][0]));data['signals'][1]['timestamp']='14:03'
        view=Tools(data).inspect_thread(data['thread_id']);self.assertNotIn('SIG-001',[s['signal_id'] for s in view['signals']]);self.assertIsNone(view['signals'][0]['timestamp'])
    def test_builtin_interface_with_stub_not_live(self):
        import agent
        original=agent.request
        payload={'allowed_signal_ids':['S1'],'summary_ids':['S1'],'action_ids':[['S1']],'message_ids':['S1'],'declared_ids':['S1']}
        value={'union_ids':['S1'],'unknown_ids':[],'union_matches':True}
        try:
            agent.request=lambda *a:{'candidates':[{'content':{'parts':[{'executableCode':{'code':'print(...)'}},{'codeExecutionResult':{'outcome':'OUTCOME_OK','output':json.dumps(value)}}]}}]}
            self.assertEqual(agent.builtin_audit('stub',payload)['verified_computation'],value)
            agent.request=lambda *a:{'candidates':[{'content':{'parts':[{'text':'I checked it'}]}}]}
            with self.assertRaises(RuntimeError): agent.builtin_audit('stub',payload)
        finally: agent.request=original
if __name__=='__main__': unittest.main(verbosity=2)
