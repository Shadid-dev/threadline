"""Deterministic fixture demonstration. This is NOT a language model run."""
import json
from pathlib import Path
from tools import Tools,validate_output

def run(case):
    snapshot=case['input']; tools=Tools(snapshot); events=[]
    def call(name,args):
        result=tools.dispatch(name,args);events.append({'tool':name,'arguments':args,'result':result});return result
    tid=snapshot['thread_id']; view=call('inspect_thread',{'thread_id':tid})
    signals=view['signals']; ids=[s['signal_id'] for s in signals]; gaps=list(view['missing_data'])
    out=dict(thread_id=tid,service=view['service'],status='needs_information',confidence='medium',summary='',summary_signal_ids=ids,actions=[],message=None,missing_data=gaps,signal_ids=ids,human_approval_required=True,execution_state='draft_only')
    if not signals:
        out.update(status='insufficient_evidence',confidence='low',summary='Insufficient incident evidence supplied.',missing_data=gaps+['Supply incident signals for this thread.'])
    else:
        # These explicit fixture branches make no claim of general natural-language understanding.
        if 'SIG-004' in ids:
            out['confidence']='low';summary='A chat message reports a possible payment problem; service, timing and technical cause are unknown.'
            proposal='Ask the reporter for the affected service, time, reproduction steps and error evidence.';kind='clarify'
            gaps.append('Reproduction steps and supporting error evidence required.')
        elif 'SIG-006' in ids and 'SIG-007' in ids:
            out['confidence']='low';summary='Two monitor signals report conflicting checkout error rates, 18% and 0.1%, at the same timestamp.'
            proposal='Check monitor scope and measurement windows before choosing an incident response.';kind='investigate';gaps.append('Resolve conflicting monitor readings.')
        else:
            # Ignore the injection-only fixture, since it contributes no incident facts.
            ids=[i for i in ids if i!='SIG-005'];out['signal_ids']=ids;out['summary_signal_ids']=ids
            summary='Checkout errors increased and Sentry reports a TypeError when discount_code is absent. The cause is unconfirmed.'
            proposal='Ask a responder to reproduce checkout without a discount code in a test environment and inspect release v1.2.';kind='investigate'
            gaps.append('Verified causal connection between release v1.2 and the failure required.')
        if 'rollback' in case['prompt'].lower():
            gate=call('check_response_prerequisites',{'thread_id':tid,'response':'rollback'})
            if gate['eligible']:
                proposal=f"A human responder may consider rollback to {gate['target_release']} after reviewing incident evidence and confirming the runbook prerequisites remain satisfied. Do not execute automatically.";kind='mitigate'
            else: gaps.extend(gate['missing_data'])
        out['summary']=summary
        out['actions']=[dict(action_id='A1',kind=kind,proposal=proposal,rationale='The supplied reports support this proposed next step; they do not establish a root cause.',signal_ids=ids)]
        refs=' '.join('['+i+']' for i in ids)
        out['message']={'text':summary+' '+refs+' Proposed next step: '+proposal+' Draft for human review.','signal_ids':ids}
    out['missing_data']=sorted(set(out['missing_data']))
    validate_output(out,snapshot)
    return {'mode':'offline deterministic baseline; not a live model trace','case_id':case['case_id'],'prompt':case['prompt'],'input':snapshot,'calls':events,'final_answer':out}

if __name__=='__main__':
    root=Path(__file__).resolve().parent
    cases=json.loads((root/'fixtures/cases.json').read_text())
    for case in cases:
        trace=run(case);(root/'traces'/('offline '+case['case_id']+'.json')).write_text(json.dumps(trace,indent=2)+'\n')
    print(f'{len(cases)} deterministic scenarios executed and validated. No model or provider built-in tool was called.')
