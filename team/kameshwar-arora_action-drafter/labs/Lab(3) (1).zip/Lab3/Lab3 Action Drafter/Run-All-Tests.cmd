@echo off
cd /d "%~dp0"
py agent.py --model gemini-3.8-flash --all --resume
powershell -NoProfile -Command "Compress-Archive -Path '.\traces\*' -DestinationPath '.\Live-Test-Results.zip' -Force"
echo.
echo Upload Live-Test-Results.zip for review. Completed does not replace behavioral review.
pause
