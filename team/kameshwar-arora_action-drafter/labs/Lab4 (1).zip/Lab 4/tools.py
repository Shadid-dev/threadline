"""Read-only tools bound to one application-provided incident snapshot."""
import copy,json
from pathlib import Path
from datetime import datetime
from collections import Counter
from jsonschema import Draft202012Validator
ROOT=Path(__file__).resolve().parent
SCHEMAS={x['name']:x['parameters'] for x in json.loads((ROOT/'tool schemas.json').read_text())}

def valid_time(value):
    try:
        dt=datetime.fromisoformat(value.replace('Z','+00:00'))
        return dt.tzinfo is not None
    except (ValueError,TypeError,AttributeError): return False

class Tools:
    def __init__(self,snapshot): self.snapshot=copy.deepcopy(snapshot)
    def dispatch(self,name,args):
        if name not in SCHEMAS: return {'ok':False,'error':'Unknown tool.'}
        errors=list(Draft202012Validator(SCHEMAS[name]).iter_errors(args))
        if errors: return {'ok':False,'error':'Invalid tool arguments.','details':[e.message for e in errors]}
        if args['thread_id']!=self.snapshot['thread_id']:
            return {'ok':False,'error':'Thread outside bound snapshot.'}
        return getattr(self,name)(**args)
    def inspect_thread(self,thread_id):
        accepted=[]; missing=[]
        signals=self.snapshot['signals']
        counts=Counter(s.get('signal_id') for s in signals if isinstance(s,dict))
        for n,s in enumerate(signals):
            if not isinstance(s,dict) or not isinstance(s.get('signal_id'),str) or not s.get('signal_id') or s.get('thread_id')!=thread_id:
                missing.append(f'Record {n+1} excluded because its identity or thread is invalid.'); continue
            if counts[s['signal_id']]!=1:
                missing.append(f"Duplicate signal ID {s['signal_id']} excluded."); continue
            if s.get('source') not in ['github','sentry','jira','slack','monitor'] or not isinstance(s.get('content'),str) or not s['content'].strip():
                missing.append(f"Signal {s['signal_id']} excluded because source or content is invalid."); continue
            s=copy.deepcopy(s)
            if not valid_time(s.get('timestamp')):
                s['timestamp']=None; missing.append(f"Valid timestamp missing for {s['signal_id']}.")
            if not isinstance(s.get('service'),str) or not s['service'].strip():
                s['service']=None; missing.append(f"Affected service missing for {s['signal_id']}.")
            accepted.append(s)
        services=sorted({s['service'] for s in accepted if s['service']})
        if len(services)>1: missing.append('Multiple services need responder review.')
        return {'ok':True,'thread_id':thread_id,'service':services[0] if len(services)==1 else None,'signals':accepted,'missing_data':sorted(set(missing))}
    def check_response_prerequisites(self,thread_id,response):
        view=self.inspect_thread(thread_id); rb=self.snapshot.get('trusted_runbook'); gaps=[]
        if not rb: gaps.append('Separately supplied trusted runbook required.')
        else:
            if not isinstance(rb,dict): return {'ok':False,'error':'Malformed trusted runbook.'}
            if rb.get('service')!=view['service'] or view['service'] is None: gaps.append('Runbook service must match the known affected service.')
            if rb.get('response')!=response: gaps.append('Runbook does not support this response.')
            if not isinstance(rb.get('target_release'),str) or not rb['target_release'].strip(): gaps.append('Verified rollback target required.')
            for k in ['target_verified','compatibility_checked','responder_identified']:
                if rb.get('prerequisites',{}).get(k) is not True: gaps.append('Required prerequisite: '+k)
        if not view['signals']: gaps.append('Usable incident evidence required.')
        return {'ok':True,'eligible':not gaps,'missing_data':gaps,'runbook_id':rb.get('runbook_id') if isinstance(rb,dict) else None,'target_release':rb.get('target_release') if isinstance(rb,dict) and not gaps else None,'human_approval_required':True,'execution_state':'draft_only'}

def validate_output(output,snapshot):
    schema=json.loads((ROOT/'output schema.json').read_text())
    Draft202012Validator(schema).validate(output)
    view=Tools(snapshot).inspect_thread(snapshot['thread_id'])
    valid={s['signal_id'] for s in view['signals']}
    if output['thread_id']!=snapshot['thread_id']: raise ValueError('Wrong thread')
    if output['service']!=view['service']: raise ValueError('Service mismatch')
    cited=set(output['summary_signal_ids'])
    for a in output['actions']: cited.update(a['signal_ids'])
    if output['message']: cited.update(output['message']['signal_ids'])
    if not cited<=valid or cited!=set(output['signal_ids']): raise ValueError('Citation membership or union mismatch')
    if len({a['action_id'] for a in output['actions']})!=len(output['actions']): raise ValueError('Duplicate action IDs')
    if any(a['kind']=='mitigate' for a in output['actions']):
        gate=Tools(snapshot).check_response_prerequisites(snapshot['thread_id'],'rollback')
        if not gate['eligible']: raise ValueError('Mitigation prerequisites incomplete')
    return True
