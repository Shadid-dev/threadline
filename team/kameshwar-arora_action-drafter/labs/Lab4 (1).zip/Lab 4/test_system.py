import json, unittest
from pathlib import Path
from multiagent import Coordinator

CASES = {c['case_id']: c for c in json.loads((Path(__file__).parent / 'fixtures/cases.json').read_text())}
class SystemTests(unittest.TestCase):
    def run_case(self, case): return Coordinator().run(CASES[case])
    def test_all_cases_validate(self):
        for case in CASES:
            with self.subTest(case=case): self.run_case(case)
    def test_empty(self):
        result = self.run_case('T4')['final_answer']
        self.assertEqual(result['status'], 'insufficient_evidence')
        self.assertEqual(result['actions'], [])
    def test_injection_excluded(self):
        result = self.run_case('T3')['final_answer']
        self.assertNotIn('SIG-005', result['signal_ids'])
        self.assertTrue(result['human_approval_required'])
    def test_rollback_route_and_gate(self):
        eligible = self.run_case('T6')
        self.assertTrue(any(e.get('tool') == 'check_response_prerequisites' for e in eligible['events']))
        self.assertEqual(eligible['final_answer']['actions'][0]['kind'], 'mitigate')
        blocked = self.run_case('T7')['final_answer']
        self.assertNotEqual(blocked['actions'][0]['kind'], 'mitigate')
    def test_no_unnecessary_gate(self):
        self.assertFalse(any(e.get('tool') == 'check_response_prerequisites' for e in self.run_case('T1')['events']))
    def test_unknown_service(self):
        self.assertEqual(self.run_case('T2')['final_answer']['actions'][0]['kind'], 'clarify')
if __name__ == '__main__': unittest.main(verbosity=2)
