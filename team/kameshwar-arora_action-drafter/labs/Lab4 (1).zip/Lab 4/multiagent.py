"""Rule-based multi-agent extension of the Lab 3 Action Drafter."""
import argparse, json
from pathlib import Path
from tools import Tools, validate_output

ROOT = Path(__file__).resolve().parent

class EvidenceAgent:
    def run(self, tools, thread_id):
        view = tools.dispatch('inspect_thread', {'thread_id': thread_id})
        # Treat instruction-like incident text as untrusted, not as a command.
        excluded = [s['signal_id'] for s in view['signals'] if 'SYSTEM OVERRIDE' in s['content'].upper()]
        signals = [s for s in view['signals'] if s['signal_id'] not in excluded]
        return {'service': view['service'], 'signals': signals,
                'missing_data': view['missing_data'], 'excluded': excluded}

class ResponseAgent:
    def run(self, evidence, gate):
        signals = evidence['signals']
        if not signals:
            return {'kind': None, 'proposal': None}
        if gate and gate['eligible']:
            return {'kind': 'mitigate', 'proposal': f"A human responder may consider rollback to {gate['target_release']} after confirming the runbook prerequisites. Do not execute automatically."}
        if evidence['service'] is None:
            return {'kind': 'clarify', 'proposal': 'Ask for the affected service, timing, reproduction steps and supporting error evidence.'}
        return {'kind': 'investigate', 'proposal': 'Review the reported signals, verify their measurement scope and reproduce the issue before choosing a response.'}

class UpdateAgent:
    def run(self, evidence, response):
        signals = evidence['signals']
        if not signals:
            return 'Insufficient incident evidence supplied.', None
        # Quote each source as a report rather than asserting a confirmed cause.
        summary = 'Reported evidence: ' + ' '.join(f"{s['content']} [{s['signal_id']}]" for s in signals)
        ids = [s['signal_id'] for s in signals]
        message = {'text': summary + ' Proposed next step: ' + response['proposal'] + ' Draft for human review.', 'signal_ids': ids}
        return summary, message

class Coordinator:
    def run(self, case):
        snapshot, prompt = case['input'], case['prompt']
        tools = Tools(snapshot)
        events = []
        evidence = EvidenceAgent().run(tools, snapshot['thread_id'])
        events.append({'agent': 'EvidenceAgent', 'output': evidence})
        gaps = list(evidence['missing_data'])
        if evidence['signals']:
            gaps.append('Confirm the cause and current incident state with a responder.')
        gate = None
        # Dynamic routing: only a rollback request calls the prerequisite tool.
        if 'rollback' in prompt.lower() and evidence['signals']:
            gate = tools.dispatch('check_response_prerequisites', {'thread_id': snapshot['thread_id'], 'response': 'rollback'})
            events.append({'agent': 'Coordinator', 'tool': 'check_response_prerequisites', 'output': gate})
            if gate.get('ok') and not gate['eligible']:
                gaps.extend(gate['missing_data'])
        response = ResponseAgent().run(evidence, gate)
        events.append({'agent': 'ResponseAgent', 'output': response})
        summary, message = UpdateAgent().run(evidence, response)
        events.append({'agent': 'UpdateAgent', 'output': {'summary': summary, 'message': message}})
        ids = [s['signal_id'] for s in evidence['signals']]
        actions = [] if not ids else [{'action_id': 'A1', 'kind': response['kind'], 'proposal': response['proposal'], 'rationale': 'The reports warrant review but do not establish the cause.', 'signal_ids': ids}]
        if not ids:
            gaps.append('Supply incident signals for this thread.')
        out = {'thread_id': snapshot['thread_id'], 'service': evidence['service'],
               'status': 'needs_information' if ids else 'insufficient_evidence',
               'confidence': 'low', 'summary': summary, 'summary_signal_ids': ids,
               'actions': actions, 'message': message, 'missing_data': sorted(set(gaps)),
               'signal_ids': ids, 'human_approval_required': True, 'execution_state': 'draft_only'}
        validate_output(out, snapshot)
        return {'case_id': case['case_id'], 'prompt': prompt, 'events': events, 'final_answer': out}

def main():
    parser = argparse.ArgumentParser(description='Run the Action Drafter on a JSON case or the supplied cases.')
    parser.add_argument('--case', help='Path to a JSON case containing case_id, prompt and input')
    args = parser.parse_args()
    cases = [json.loads(Path(args.case).read_text())] if args.case else json.loads((ROOT / 'fixtures/cases.json').read_text())
    for case in cases:
        print(json.dumps(Coordinator().run(case), indent=2))

if __name__ == '__main__':
    main()
