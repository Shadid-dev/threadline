"""Four autonomous-in-role specialists and message-based handoffs.

The offline policies are deterministic, not simulated LLM calls. An optional Gemini
backend can supply draft analysis/review; local validation remains authoritative.
"""
from __future__ import annotations
import copy
from dataclasses import dataclass
from typing import Any

from attribution import choose_attribution
from tools import execute_tool


class ToolError(RuntimeError):
    pass


@dataclass
class AgentState:
    calls: int = 0
    last_result: Any = None


class EvidenceAgent:
    """Goal: acquire incident-specific evidence; never reason from other threads."""
    name = "EvidenceAgent"

    def __init__(self):
        self.state = AgentState()

    def investigate(self, thread_id: str, log: list, orchestrator) -> dict:
        self.state.calls += 1
        inputs = [
            ("get_incident_signals", {"thread_id": thread_id}),
            ("list_code_change_signals", {"thread_id": thread_id}),
            ("assess_change_candidates", {"thread_id": thread_id, "window_minutes": 30}),
        ]
        collected = {}
        for name, args in inputs:
            result = execute_tool(name, args)
            orchestrator.event(log, self.name, name, "tool_call", {"arguments": args, "result": result})
            if not result.get("ok"):
                raise ToolError(f"{name}: {result.get('error', 'unknown error')}")
            collected[name] = result["result"]
        outcome = {
            "thread_id": thread_id,
            "signals": collected["get_incident_signals"]["signals"],
            "changes": collected["list_code_change_signals"]["code_changes"],
            "assessment": collected["assess_change_candidates"],
        }
        self.state.last_result = copy.deepcopy(outcome)
        return outcome


class AttributionAgent:
    """Goal: propose a Lab 2 six-field attribution based on assessed evidence."""
    name = "AttributionAgent"

    def __init__(self, backend=None, fault_once=False):
        self.state = AgentState()
        self.backend = backend
        self.fault_once = fault_once

    def propose(self, evidence: dict, feedback: dict | None = None) -> dict:
        self.state.calls += 1
        thread_id = evidence["thread_id"]
        if self.backend is None:
            # Delegation to the original Lab 3 policy constitutes its offline
            # decision rule, rather than a hidden model or fabricated response.
            decision = choose_attribution(thread_id)
        else:
            decision = self.backend.propose_attribution(evidence, feedback)
        if self.fault_once and self.state.calls == 1:
            # Labelled fault injection only, used to test coordinator repair.
            decision = copy.deepcopy(decision)
            decision["confidence"] = "low" if decision.get("confidence") != "low" else "high"
        self.state.last_result = copy.deepcopy(decision)
        return decision


class VerificationAgent:
    """Goal: independently gate schema, provenance, and Lab 2 policy consistency."""
    name = "VerificationAgent"

    def __init__(self):
        self.state = AgentState()

    def check(self, evidence: dict, proposal: dict, log: list, orchestrator) -> dict:
        self.state.calls += 1
        thread_id = evidence["thread_id"]
        args = {"thread_id": thread_id, "decision": proposal}
        response = execute_tool("validate_attribution_output", args)
        orchestrator.event(log, self.name, "validate_attribution_output", "tool_call", {"arguments": args, "result": response})
        errors = []
        if not response.get("ok"):
            errors.append(f"Invalid tool arguments: {response.get('error')}")
        else:
            errors += response["result"].get("errors", [])
        expected = choose_attribution(thread_id)
        if not isinstance(proposal, dict):
            errors.append("Proposal is not a JSON object")
        else:
            for key in ("thread_id", "attributed_change_signal_id", "confidence", "evidence_signal_ids", "missing_information"):
                if proposal.get(key) != expected[key]:
                    errors.append(f"Policy mismatch: {key}; expected {expected[key]!r}")
            if not isinstance(proposal.get("reason"), str) or not proposal.get("reason", "").strip():
                errors.append("Reason must explain the evidence")
        verdict = {"approved": len(errors) == 0, "errors": errors,
                   "expected_policy": {"attributed_change_signal_id": expected["attributed_change_signal_id"],
                                       "confidence": expected["confidence"]}}
        self.state.last_result = copy.deepcopy(verdict)
        return verdict


class ReviewAgent:
    """Goal: generate a cautious human-facing summary, never take remediation."""
    name = "ReviewAgent"

    def __init__(self, backend=None):
        self.state = AgentState()
        self.backend = backend

    def summarize(self, evidence: dict, approved_decision: dict) -> dict:
        self.state.calls += 1
        if self.backend:
            summary = self.backend.propose_review(evidence, approved_decision)
        else:
            summary = {"thread_id": evidence["thread_id"],
                       "summary": approved_decision["reason"],
                       "cited_signal_ids": approved_decision["evidence_signal_ids"],
                       "requires_human_approval": True}
        errors = []
        if not isinstance(summary, dict):
            raise ValueError("Review proposal must be a JSON object")
        if set(summary) != {"thread_id", "summary", "cited_signal_ids", "requires_human_approval"}:
            errors.append("Review proposal keys are incorrect")
        if summary.get("thread_id") != evidence["thread_id"]:
            errors.append("Review thread mismatch")
        if summary.get("requires_human_approval") is not True:
            errors.append("Review cannot bypass human approval")
        if not isinstance(summary.get("summary"), str) or not summary.get("summary", "").strip():
            errors.append("Review summary is empty")
        citations = summary.get("cited_signal_ids")
        if not isinstance(citations, list) or len(set(map(str, citations))) != len(citations):
            errors.append("Review citations must be a unique list")
        else:
            allowed = {s["signal_id"] for s in evidence["signals"] if s.get("source") != "slack"}
            if any(c not in allowed for c in citations):
                errors.append("Review contains unknown or untrusted citation")
            if citations != approved_decision["evidence_signal_ids"]:
                errors.append("Review citations must equal verified evidence IDs")
        if errors:
            raise ValueError("; ".join(errors))
        self.state.last_result = copy.deepcopy(summary)
        return summary
