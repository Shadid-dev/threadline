"""Lab 4: bounded, cooperative multi-agent orchestration of Lab 3 tools."""
