"""Central, bounded orchestration; explicit message trace for static and dynamic paths."""
from __future__ import annotations
import copy
from pathlib import Path
import json
from mas.agents import EvidenceAgent, AttributionAgent, VerificationAgent, ReviewAgent


class Coordinator:
    def __init__(self, backend=None, fault_once=False):
        self.evidence = EvidenceAgent()
        self.analyst = AttributionAgent(backend, fault_once=fault_once)
        self.verifier = VerificationAgent()
        self.reviewer = ReviewAgent(backend)

    @staticmethod
    def event(log, sender, recipient, kind, payload):
        log.append({"seq": len(log) + 1, "from": sender, "to": recipient,
                    "kind": kind, "payload": copy.deepcopy(payload)})

    def run(self, thread_id: str, mode: str = "dynamic", prompt: str | None = None, trace: Path | None = None) -> dict:
        if mode not in {"static", "dynamic"}:
            raise ValueError("mode must be static or dynamic")
        log = []
        self.event(log, "user", "Coordinator", "request",
                   {"thread_id": thread_id, "prompt": prompt or f"Investigate incident {thread_id}", "mode": mode})
        decision, review = None, None
        status = "needs_human_review"
        try:
            self.event(log, "Coordinator", "EvidenceAgent", "dispatch", {"thread_id": thread_id})
            evidence = self.evidence.investigate(thread_id, log, self)
            self.event(log, "EvidenceAgent", "Coordinator", "evidence_returned",
                       {"signals": len(evidence["signals"]), "changes": len(evidence["changes"]),
                        "first_failure": evidence["assessment"]["first_failure_signal_id"]})

            # Static: one analysis + verification pass. Dynamic: at most two passes,
            # with content feedback. Never repeat indefinitely.
            maximum_attempts = 1 if mode == "static" else 2
            feedback = None
            for attempt in range(1, maximum_attempts + 1):
                self.event(log, "Coordinator", "AttributionAgent", "dispatch",
                           {"attempt": attempt, "feedback": feedback})
                proposal = self.analyst.propose(evidence, feedback)
                self.event(log, "AttributionAgent", "Coordinator", "proposal", proposal)
                self.event(log, "Coordinator", "VerificationAgent", "dispatch", {"attempt": attempt})
                verdict = self.verifier.check(evidence, proposal, log, self)
                self.event(log, "VerificationAgent", "Coordinator", "verdict", verdict)
                if verdict["approved"]:
                    decision = proposal
                    break
                feedback = {"errors": verdict["errors"], "attempt": attempt}
                self.event(log, "Coordinator", "AttributionAgent" if attempt < maximum_attempts else "human",
                           "revise" if attempt < maximum_attempts else "escalate", feedback)

            if decision is None:
                status = "needs_human_review"
            elif mode == "dynamic" and decision["confidence"] == "low":
                # Dynamic policy conserves work and does not publish unsupported text.
                self.event(log, "Coordinator", "ReviewAgent", "skip",
                           {"why": "low confidence; send evidence to human review"})
                status = "needs_human_review"
            else:
                self.event(log, "Coordinator", "ReviewAgent", "dispatch",
                           {"confidence": decision["confidence"]})
                review = self.reviewer.summarize(evidence, decision)
                self.event(log, "ReviewAgent", "Coordinator", "review_proposal", review)
                status = "ready_for_human_review" if decision["confidence"] != "low" else "needs_human_review"
        except Exception as exc:
            # Fail closed: no unverified attribution or review text is published.
            decision, review = None, None
            status = "needs_human_review"
            self.event(log, "Coordinator", "human", "error_escalation",
                       {"type": type(exc).__name__, "detail": str(exc)[:240]})

        counts = {agent.name: agent.state.calls for agent in
                  (self.evidence, self.analyst, self.verifier, self.reviewer)}
        result = {"thread_id": thread_id, "mode": mode, "status": status,
                  "attribution": decision, "review": review, "agent_calls": counts,
                  "requires_human_approval": True}
        self.event(log, "Coordinator", "user", "final", result)
        if trace:
            trace.parent.mkdir(parents=True, exist_ok=True)
            trace.write_text(json.dumps({"prompt": prompt, "result": result, "events": log}, indent=2), encoding="utf-8")
        return result
