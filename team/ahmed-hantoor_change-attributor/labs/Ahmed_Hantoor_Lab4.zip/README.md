# INSE 691 – Lab 4 | ThreadLine Multi-Agent Change Attributor

**Student:** Ahmed Hantoor · **ID:** 40326983  
**Course:** Foundations of AI Agent Systems · **Assignment:** Lab 4 (Individual)

This is an **individual extension of the student's Lab 3 change-attribution agent**, not a copy of the group leader's separate correlator project. It preserves the original `tools.py`, `attribution.py`, JSON fixtures, and schema. It introduces **three additional specialist agents**, for a total of four roles, plus a central coordinator:

1. `EvidenceAgent` — collects current-thread signals, code changes and the precise 30-minute calculation using the Lab 3 custom tools.
2. `AttributionAgent` — proposes one six-field attribution using Lab 2 policy or optional Gemini.
3. `VerificationAgent` — checks JSON/schema, evidence references and the *semantic policy*, including low/medium/high confidence (the Lab 3 live issue).
4. `ReviewAgent` — creates a brief evidence-cited summary requiring human approval (never executes changes).

The **Coordinator** passes messages between agents, logs each decision, and implements static or dynamic orchestration. This is a bounded agent-based prototype; offline agent reasoning is rule-based, and code-directed dynamic routing should not be confused with autonomous LLM planning.

## Requirements

- Python 3.10+ (works with Python 3.14)
- Internet **not required** for offline tests
- Install dependencies once with:

```powershell
py -m pip install -r requirements.txt
```

## Windows PowerShell: run together, in order

Open the ZIP in File Explorer, click **Extract All**, open the extracted `Lab4_ChangeAttributor_AhmedHantoor_40326983` folder, click its address bar, type `powershell`, and press Enter. Run:

```powershell
py -m pip install -r requirements.txt
py -m unittest discover -s tests -v
py run_lab4.py --suite --mode dynamic --trace traces\my_dynamic.json
py run_lab4.py --suite --mode static --trace traces\my_static.json
py run_lab4.py --thread THR-L301 --mode dynamic --trace traces\my_incident.json
py run_lab4.py --thread THR-L302 --mode dynamic --fault-once --trace traces\my_repair.json
```

Expected offline outputs: **20 tests passed**, **7/7 static and 7/7 dynamic prompts passed**, `THR-L301` confidence `high`, `THR-L302` confidence `medium` even after a deliberately injected first-answer confidence error (2 analysis/verification rounds). `--fault-once` is an artificial test condition, **not** a real Gemini response.

### Static vs dynamic behavior

- **Static:** Evidence -> Analyst -> Verifier -> Reviewer (one decision attempt); verification failure escalates immediately.
- **Dynamic:** Evidence -> Analyst -> Verifier -> (one feedback-driven retry if rejected) -> Reviewer only for high/medium results; low confidence skips Reviewer and escalates. Maximum 2 proposal rounds. No automatic incident remediation.

`traces/static_suite.json` and `traces/dynamic_suite.json` contain summary outputs for all seven offline scenarios. `traces/dynamic_THR-L301.json` is a **complete trace** with tool calls/arguments/results and inter-agent messages. `traces/dynamic_repair_demo.json` is a **complete trace** of the *deliberate* confidence fault being rejected and repaired. The code can produce new detailed traces with `--trace`.

### Optional: Gemini agents (real API key, not required)

Use your own **new, private** Gemini API key in PowerShell and run the command in the same terminal session:

```powershell
$secureKey = Read-Host 'Gemini API key (hidden)' -AsSecureString
$env:GEMINI_API_KEY = [System.Net.NetworkCredential]::new('', $secureKey).Password.Trim()
py run_lab4.py --backend gemini --model gemini-2.5-flash --thread THR-L301 --mode dynamic --trace traces\my_live_lab4.json
```

Two **separate** model-backed specialist calls may occur: AttributionAgent, then ReviewAgent. EvidenceAgent and VerificationAgent remain local. If the verifier rejects attribution, a second AttributionAgent request can occur. Invalid or failed model outputs **do not** silently become an offline success. **Live backend verified on the user's Windows computer:** Gemini 2.5 Flash successfully completed `THR-L301` (`SIG-L301`, `high`) and `THR-L302` (`SIG-L304`, `medium`) with one call for each specialist in dynamic mode. See `traces/my_live_fixed.json` and `traces/my_live_L302.json`. Evidence and Verification were local; Gemini provided Attribution and Review proposals. Keep the key secret.

No key is required in any file; do not include `.env`, keys, or tokens in your submission. The Lab 3 `agent.py` is included for context but is not the Lab 4 coordinator. The separate Lab 3 `builtin_audit.py` script is not required or included in this package.

## Test inputs

`lab4_test_prompts.json` lists all seven prompts and expected results. Cases are: four-minute release, 90-minute old release, missing metadata, Slack prompt-injection, no code-change signal, two tied changes, and exactly 30-minute window boundary. The full test suite includes additional checks for static/dynamic routing, semantics, fabricated citations, human approval, missing thread, and the feedback/repair loop.

## Submission / limitations

- Review `LAB4_REPORT_FINAL_CLEAN.pdf` and **write/personalize your final report yourself**. The instructor explicitly requires individual work and the ability to defend each decision.
- This uses synthetic fixture data. There is no production connector, concurrency, real deployment or rollback, or implemented human approval UI.
- Offline agents are deterministic role-specialists. The separate model-backed Gemini specialist runs are documented in `traces/my_live_fixed.json` and `traces/my_live_L302.json`, although the traces do not contain independent provider-side attestation.
- Reviewer validation checks keys, citation IDs and approval but does not exhaustively prove prose is free of hallucination.
- Existing Lab 3 semantic checks reuse the baseline policy; that is consistent but not wholly independent verification.

## File map

- `mas/agents.py` — four specialist agents
- `mas/coordinator.py` — static/dynamic orchestration, message trace
- `mas/model_backend.py` — optional model-backed Analyst/Reviewer
- `run_lab4.py` — demo and seven-prompt CLI
- `tests/test_lab4.py` — Lab 4 regression tests
- `tools.py`, `attribution.py`, `tool_schemas.json`, `fixtures/` — user's Lab 3 foundation
- `traces/` — detailed offline execution, fault-recovery, static escalation, test suites, and two captured live model-backed runs
- `LAB4_REPORT_FINAL_CLEAN.pdf` — final report (review and personalize before submission)
