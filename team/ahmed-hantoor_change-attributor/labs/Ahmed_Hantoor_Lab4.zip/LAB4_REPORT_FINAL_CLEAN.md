# INSE 691 — Lab #4: Multi-Agent Orchestration
**Student:** Ahmed Hantoor · **ID:** 40326983 · **Fall 2026**

## 1. Functionality summary

My Lab 4 extends the tool-using ThreadLine Change Attributor from Lab 3 into a small cooperative multi-agent investigation system. It investigates one incident at a time and asks which code change, if any, can reasonably be linked to its earliest failure. The evidence consists of synthetic GitHub/deployment records, Sentry failures, monitoring alerts and potentially misleading Slack messages. Lab 3 already established four read-only custom tools and a strict rule: a matching service and a preceding change within an inclusive 30-minute window support high confidence; a single confirmed clue may support medium confidence; missing or conflicting evidence leads to low confidence or abstention.

Rather than give all responsibilities to one agent, this version divides the work among evidence collection, attribution reasoning, independent verification and human-review summarization. A central coordinator delivers structured messages and routes work either through a fixed static workflow or a bounded dynamic workflow that can request one correction when a proposal fails validation. The design addresses an observed Lab 3 live-test weakness: a language model gave low confidence to a same-service deployment that occurred 90 minutes before failure, although the specified policy required medium. A semantic verifier now checks that distinction, not just JSON syntax. Outputs are recommendations only; no agent can push code, issue a rollback or contact users. Human approval is mandatory.

## 2. System structure and justification

- **EvidenceAgent (new role relative to the original single-agent workflow):** goal = get trustworthy incident-local information. Input = thread ID; tools = `get_incident_signals`, `list_code_change_signals`, `assess_change_candidates`; output = read-only evidence packet containing signals, changes, first failure and candidate matches. Attributes = call counter and last result. It rejects failed tool calls.
- **AttributionAgent (original Lab 3 responsibility isolated):** goal = propose the six-field Lab 2 decision. Input = evidence packet and any validator feedback. Offline behavior delegates to existing `choose_attribution`; optional Gemini mode drafts JSON. Attributes = call counter, latest proposal and optional one-time test fault. It never alters evidence.
- **VerificationAgent (additional specialist):** goal = catch unsupported or contract-breaking decisions. Input = proposal and incident evidence; tool = `validate_attribution_output`; additionally compare selected change, confidence, missing fields and evidence IDs against the deterministic Lab 2 policy. Output = approved/rejected verdict and explicit errors. Attributes = call counter and last verdict. This is partly a shared-policy consistency check, not independent causal truth.
- **ReviewAgent (additional specialist):** goal = package an approved result for a human. Input = verified attribution; output = short summary, exact verified citations and `requires_human_approval=true`. It validates provenance and cannot publish an unknown signal ID. Attributes = call counter and last review.
- **Coordinator (orchestrator, not a fifth reasoning specialist):** reads agent verdicts, dispatches messages, applies static/dynamic routing, logs sequence and terminates on error. It holds the per-request workflow state, not secret credentials.

All agents cooperate under a central manager rather than negotiate. The inputs and output contract are inherited from the student's Lab 3; the leader's project was consulted for assignment structure only and is not this system's code base.

## 3. Agent decision making

EvidenceAgent invokes the three existing tools under the schema/30-minute constraints and stops when a tool reports an error. AttributionAgent uses the original Lab 2 rules: high for both service and timing clues, medium for one confirmed clue, low when neither is usable or candidates tie, and no selection on a known wrong service. VerificationAgent first checks structure and citations using the tool, then checks semantic policy consistency. It rejects a well-formed but wrong-confidence proposal. ReviewAgent refuses an unverified citation, incorrect thread ID, missing summary or an attempt to bypass human approval. Optional Gemini requests are treated as untrusted proposals; the local verifier is the acceptance gate. Neither the model nor the offline policies are permitted to execute remediation.

## 4. Coordination and orchestration

**Static sequence:** coordinator -> evidence -> attribution -> verification -> review (if approved). Each specialist runs once. A rejected proposal escalates rather than being silently corrected. Even with low-confidence approved decisions, static coordination runs ReviewAgent to prepare a human-visible caution.

**Dynamic routing:** after evidence and attribution, the verifier may reject a proposal. The coordinator forwards its explicit errors to AttributionAgent for one additional proposal, and runs VerificationAgent again. At most two iterations are allowed. If still invalid, it escalates without publishing a decision. If the valid decision has low confidence, ReviewAgent is skipped and the incident is sent directly to human review. With medium/high confidence, ReviewAgent prepares an evidence-grounded summary requiring approval. Any tool or model exception also escalates. Static and dynamic runs use the same four agents but different routing rules.

**Communication:** JSON-like messages carry `from`, `to`, `seq`, `kind` and `payload`. Traces include requests, dispatches, tool calls with full arguments/results, proposed decisions, validation verdicts, revision feedback, review summary and final status. Data is scoped to a single thread. There is no inter-agent negotiation, persistent cross-thread memory or parallel scheduling; dynamic scheduling is code-directed from runtime results.

## 5. Seven test prompts and observed outputs

| ID | Prompt/scenario | Expected result | Offline observed |
|---|---|---|---|
| P01 | Search release 4 minutes before failure | SIG-L301 / high | PASS static + dynamic |
| P02 | Checkout release 90 minutes before failure | SIG-L304 / medium | PASS static + dynamic |
| P03 | Missing service and timestamp | null / low | PASS static + dynamic |
| P04 | Wrong-service code change plus malicious Slack text | null / low | PASS static + dynamic |
| P05 | Failure without a code change | null / low | PASS static + dynamic |
| P06 | Two equally supported payments deployments | null / low | PASS static + dynamic |
| P07 | Deployment exactly 30 minutes before failure | SIG-L316 / high | PASS static + dynamic |

Actual prompt strings and expected outputs: `lab4_test_prompts.json`. The two seven-prompt suites were executed locally, with **7/7 passed in static** and **7/7 passed in dynamic**. `python -m unittest discover -s tests -v` also passed **20/20 tests** (10 Lab 3 and 10 Lab 4 test methods; a test method can cover more than one scenario).

**Detailed trace A (THR-L301, dynamic):** EvidenceAgent requests the three local tools. They return signals SIG-L301/302/303, change SIG-L301, first failure SIG-L302 and a +4 minute gap. AttributionAgent proposes SIG-L301/high. VerificationAgent checks the six-field schema/IDs and policy; approved. ReviewAgent provides an evidence-cited summary and approval requirement. Final status: `ready_for_human_review`. Full record: `traces/dynamic_THR-L301.json`.

**Detailed trace B (THR-L302, dynamic fault-injection):** For a controlled test, AttributionAgent's first proposal is intentionally modified to the wrong confidence (`low`). This is a **synthetic test fault, not a captured Gemini error**. VerificationAgent rejects it, citing expected `medium`. Coordinator sends feedback; AttributionAgent's second proposal is `SIG-L304/medium`, which validates. ReviewAgent then prepares the summary. Final status: `ready_for_human_review`. Full record: `traces/dynamic_repair_demo.json`. Running the same deliberate fault in static mode escalates without a retry (`traces/static_escalation_demo.json`).

## 6. Working prototype and limits

From the extracted project folder on Windows PowerShell: `py -m pip install -r requirements.txt`, `py -m unittest discover -s tests -v`, `py run_lab4.py --suite --mode dynamic`, `py run_lab4.py --suite --mode static`. For a detailed trace: `py run_lab4.py --thread THR-L301 --mode dynamic --trace traces\my_trace.json`. The `--backend gemini` option requests **two distinct specialist model outputs**, and was successfully tested with a private API key in two live incident scenarios. The original Lab 3 provider traces are historical Lab 3 evidence, not Lab 4 live evidence.

Limitations: synthetic local data; no real production connectors or action execution; human approval is a requirement marker rather than an implemented UI; confidence labels are policy categories, not calibrated probabilities; ReviewAgent checks citations but does not fully detect unsupported prose; both analyst and semantic verifier share the same reference policy, so a bug in that policy may affect both. Offline tests remain deterministic. Separate live Gemini specialist results are recorded in traces/my_live_fixed.json and traces/my_live_L302.json. More testing is needed before production use.

**Source basis:** INSE 691 Lab #4 handout (Oct 27, 2026); student's Lab 3 project and fixtures; group leader's project provided as structure-only reference. No project code was taken from the group leader's MAS.

## 7. Live Gemini verification results

After the offline tests, I tested the optional Gemini 2.5 Flash backend in dynamic coordination mode. Gemini generated AttributionAgent and ReviewAgent responses, while EvidenceAgent and VerificationAgent remained local.

**THR-L301:** The system identified SIG-L301 with high confidence. The change occurred four minutes before the search failure. All four agents ran once, verification passed, and the final status was ready_for_human_review.

**THR-L302:** The system identified SIG-L304 with medium confidence. The checkout deployment occurred 90 minutes before the failure, outside the inclusive 30-minute window, but the service matched. All four agents ran once, and verification passed.

**Implementation correction:** During an earlier THR-L301 live attempt, Gemini returned the confidence label "High" instead of the schema-required "high". I added lowercase normalization before validation. The independent semantic policy check remains active. After the correction, all 20 unit tests passed and both live scenarios completed successfully.

**Additional tests:** Seven of seven dynamic scenarios passed. An intentionally incorrect attribution was rejected and corrected through one additional AttributionAgent and VerificationAgent cycle.

**Evidence:** traces/my_live_fixed.json, traces/my_live_L302.json, traces/my_repair.json.

**Scope:** These live tests verify model-backed specialist responses under centrally controlled orchestration. They do not demonstrate autonomous Gemini tool selection or production incident-response capability.
