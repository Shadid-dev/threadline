"""CLI demonstrations of the Lab 4 MAS (no API key required offline)."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
from mas.coordinator import Coordinator


def main():
    p=argparse.ArgumentParser(description='Lab 4 ThreadLine multi-agent prototype')
    p.add_argument('--thread', default='THR-L301')
    p.add_argument('--mode', choices=['static','dynamic'], default='dynamic')
    p.add_argument('--backend', choices=['offline','gemini'], default='offline')
    p.add_argument('--model', default='gemini-2.5-flash')
    p.add_argument('--trace', type=Path)
    p.add_argument('--suite', action='store_true', help='Run all seven scenarios and save a combined trace')
    p.add_argument('--fault-once', action='store_true', help='DEMO fault injection (not a Gemini error)')
    args=p.parse_args()
    backend = None
    if args.backend=='gemini':
        from mas.model_backend import GeminiSpecialistBackend
        backend=GeminiSpecialistBackend(args.model)
    if args.suite:
        scenarios=json.loads(Path('lab4_test_prompts.json').read_text(encoding='utf-8'))
        results=[]
        for item in scenarios:
            c=Coordinator(backend=backend)
            result=c.run(item['thread_id'], args.mode, item['prompt'])
            outcome=result['attribution'] or {}
            result['expected_confidence']=item['expected_confidence']
            result['expected_change']=item['expected_change']
            result['passed']=(outcome.get('confidence')==item['expected_confidence'] and
                              outcome.get('attributed_change_signal_id')==item['expected_change'])
            results.append(result)
            print(item['id'], 'PASS' if result['passed'] else 'FAIL',
                  result['status'], 'confidence='+str(outcome.get('confidence')))
        if args.trace:
            args.trace.parent.mkdir(parents=True,exist_ok=True)
            args.trace.write_text(json.dumps(results,indent=2),encoding='utf-8')
        print(f"Passed: {sum(r['passed'] for r in results)}/{len(results)}")
    else:
        c=Coordinator(backend=backend, fault_once=args.fault_once)
        result=c.run(args.thread,args.mode,trace=args.trace)
        print(json.dumps(result,indent=2))

if __name__=='__main__':main()
