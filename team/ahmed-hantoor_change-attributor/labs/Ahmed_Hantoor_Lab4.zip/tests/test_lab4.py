import json
import unittest
from pathlib import Path
from mas.coordinator import Coordinator
from mas.agents import ReviewAgent, VerificationAgent
from tools import get_incident_signals, assess_change_candidates

class MultiAgentTests(unittest.TestCase):
    def test_seven_scenarios_both_modes(self):
        scenarios=json.loads(Path('lab4_test_prompts.json').read_text(encoding='utf-8'))
        for scenario in scenarios:
            for mode in ('static','dynamic'):
                with self.subTest(scenario=scenario['id'], mode=mode):
                    out=Coordinator().run(scenario['thread_id'],mode)
                    self.assertEqual(out['attribution']['confidence'],scenario['expected_confidence'])
                    self.assertEqual(out['attribution']['attributed_change_signal_id'],scenario['expected_change'])
                    self.assertTrue(out['requires_human_approval'])

    def test_agents_are_coordinated(self):
        out=Coordinator().run('THR-L301','dynamic',trace=Path('traces/test_smoke.json'))
        self.assertEqual(out['agent_calls'],{'EvidenceAgent':1,'AttributionAgent':1,'VerificationAgent':1,'ReviewAgent':1})
        data=json.loads(Path('traces/test_smoke.json').read_text(encoding='utf-8'))
        self.assertTrue(any(e['kind']=='tool_call' for e in data['events']))
        self.assertTrue(any(e['from']=='VerificationAgent' and e['kind']=='verdict' for e in data['events']))

    def test_dynamic_skips_review_on_low(self):
        out=Coordinator().run('THR-L303','dynamic')
        self.assertEqual(out['agent_calls']['ReviewAgent'],0)
        self.assertIsNone(out['review'])

    def test_static_runs_review_even_low(self):
        out=Coordinator().run('THR-L303','static')
        self.assertEqual(out['agent_calls']['ReviewAgent'],1)
        self.assertEqual(out['status'],'needs_human_review')

    def test_fault_injection_repaired_only_in_dynamic(self):
        static=Coordinator(fault_once=True).run('THR-L302','static')
        dynamic=Coordinator(fault_once=True).run('THR-L302','dynamic')
        self.assertIsNone(static['attribution'])
        self.assertEqual(static['agent_calls']['AttributionAgent'],1)
        self.assertEqual(dynamic['attribution']['confidence'],'medium')
        self.assertEqual(dynamic['agent_calls']['AttributionAgent'],2)
        self.assertEqual(dynamic['agent_calls']['VerificationAgent'],2)

    def test_verifier_rejects_wrong_confidence_even_if_json_valid(self):
        from attribution import choose_attribution
        result=choose_attribution('THR-L302')
        result['confidence']='low'
        evidence={'thread_id':'THR-L302'}
        verdict=VerificationAgent().check(evidence,result,[],Coordinator())
        self.assertFalse(verdict['approved'])
        self.assertTrue(any('confidence' in e for e in verdict['errors']))

    def test_review_citations_rejected(self):
        from attribution import choose_attribution
        data={'thread_id':'THR-L301','signals':get_incident_signals('THR-L301')['signals']}
        class Fake:
            def propose_review(self,*args):return {'thread_id':'THR-L301','summary':'Fine','cited_signal_ids':['SIG-FAKE'],'requires_human_approval':True}
        with self.assertRaises(ValueError): ReviewAgent(backend=Fake()).summarize(data,choose_attribution('THR-L301'))

    def test_review_cannot_bypass_approval(self):
        from attribution import choose_attribution
        data={'thread_id':'THR-L301','signals':get_incident_signals('THR-L301')['signals']}
        class Fake:
            def propose_review(self,*args):return {'thread_id':'THR-L301','summary':'Fine','cited_signal_ids':['SIG-L301','SIG-L302','SIG-L303'],'requires_human_approval':False}
        with self.assertRaises(ValueError): ReviewAgent(backend=Fake()).summarize(data,choose_attribution('THR-L301'))

    def test_missing_thread_escalates(self):
        res=Coordinator().run('THR-NOT-FOUND','dynamic')
        self.assertEqual(res['attribution']['confidence'],'low')
        self.assertEqual(res['status'],'needs_human_review')

    def test_window_boundary(self):
        result=assess_change_candidates('THR-L307',30)
        self.assertEqual(result['candidates'][0]['minutes_before_failure'],30)
        self.assertTrue(result['candidates'][0]['timing_match'])

if __name__=='__main__':unittest.main()
