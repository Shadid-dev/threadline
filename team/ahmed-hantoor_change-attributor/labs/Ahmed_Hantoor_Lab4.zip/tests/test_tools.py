import unittest
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from attribution import choose_attribution
from tools import assess_change_candidates, execute_tool, get_incident_signals

class ToolContractTests(unittest.TestCase):
    def test_exact_window_boundary(self):
        c = assess_change_candidates("THR-L307", 30)["candidates"][0]
        self.assertEqual(c["minutes_before_failure"], 30)
        self.assertTrue(c["timing_match"])

    def test_missing_data_not_hallucinated(self):
        result = choose_attribution("THR-L303")
        self.assertEqual(result["confidence"], "low")
        self.assertIsNone(result["attributed_change_signal_id"])
        self.assertIn("service of SIG-L306", result["missing_information"])
        self.assertIn("timestamp of SIG-L307", result["missing_information"])

    def test_injection_is_data_not_instruction(self):
        r = choose_attribution("THR-L304")
        self.assertIsNone(r["attributed_change_signal_id"])
        self.assertEqual(r["confidence"], "low")
        self.assertNotIn("SIG-L309", r["evidence_signal_ids"])

    def test_known_wrong_service_blocks_attribution(self):
        self.assertIsNone(choose_attribution("THR-L304")["attributed_change_signal_id"])

    def test_equal_candidates_no_guessing(self):
        self.assertIsNone(choose_attribution("THR-L306")["attributed_change_signal_id"])

    def test_unknown_fields_denied(self):
        r = execute_tool("get_incident_signals", {"thread_id": "THR-L301", "delete": True})
        self.assertFalse(r["ok"])

    def test_window_cannot_be_changed(self):
        r = execute_tool("assess_change_candidates", {"thread_id": "THR-L301", "window_minutes": 120})
        self.assertFalse(r["ok"])

    def test_unlisted_tool_denied(self):
        self.assertFalse(execute_tool("rollback", {})["ok"])

    def test_output_validated(self):
        result = choose_attribution("THR-L301")
        self.assertTrue(execute_tool("validate_attribution_output", {"thread_id": "THR-L301", "decision": result})["result"]["valid"])

    def test_thread_isolation(self):
        got = get_incident_signals("THR-L301")
        self.assertTrue(all(s["thread_id"] == "THR-L301" for s in got["signals"]))

if __name__ == "__main__":
    unittest.main()
